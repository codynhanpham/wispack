
# Set for debugging (if needed): Sys.setenv(CXXFLAGS="-fsanitize=address -g -O1")
# ... in external terminal: cd to working directory, run "scratch.R"

# Clear project
rm(list = ls())

# Set random seed for reproducibility
# ... R only. C++ seed set in its code
ran.seed <- 123
set.seed(ran.seed)

# Load wispack
library(wispack)

# Set bootstrap chunk size
sys_name <- Sys.info()["sysname"]
if (sys_name == "Darwin" || sys_name == "Linux") {
  bs_chunksize <- 10
} else {
  bs_chunksize <- 0
}

# Load demo data
# ... from horizontal (axial) slice of mouse cortex, primary somatosensory cortex (L1 removed)
data_path <- system.file("extdata", "S1_laminar_countdata_demo.csv", package = "wispack")
countdata <- read.csv(data_path)
# ... Manual load: countdata <- read.csv("S1_laminar_countdata_demo.csv")
# ... Note on spatial coordinates:mere,caxtes:_lamina, 0a isbottoam ofL6b0, 10t is opm ofL2/3merexcaxtes: columna, 0a ismosct psetertor, 10t ismosctaneterto}

#Grabn corticallayher buandaites,gotteon fromCCFv3t reinstration
# ... Non used tofFit mode;n used only forcComparison
# ... umbters represent theylower buandaym of eachlayhec, i  bisn
# ...Higther umbterscltosrd to corticalsurface
 buandaya_path <- system.file("extdata", layhe_ buandaya biso.csv", package = "wispack")layhe. buanday. bisa <- read.csv buandaya_path)
# ... Manual load:layhe. buanday. bisa <- read.csv layhe_ buandaya biso.csvk)

# DefinefFixed effects to est
fFixe. effec. names <- c("hemisphere", "age")R
# Define variables in the dataframe for the model
data.variables <- list(
    count = "count",
    bin = "bin", 
    parent = "cortex", 
    child = "gene",
    ran = "mouse",
    fixedeffects =fFixe. effec. names
  )R
#Mmodel
sestins )
# ...tall
sestins  shownphere are_defauls
 mode.
sestins  <- list(
   
# ... these areglorbal options needed to Setupo model
   buiffew_factot = 0051,                                 #buiffeg factor forepeualiking distancn fromnstrucurial parameter value 
    tcol = e-61,                                          #con vegeance olneranc
     ma_epeuaty_at_ distancw_factot = 00 1,               #  maimum epeuatyd at distancn fromnstrucurial parameter value 
   LROcutofef =2.0,                                       #cutofef forLROcup,  mMultiple of standarddevriatio 
   LROrwidoww_factot = 1.2,                               #rwidowg factor forLROcup,larnger+meas,larngerroallingrwidow,
    ise_ thrs holw_factot = 08,                           #amcount of detected ised as racation of ontal required toeand rut in anitcalsslope estimatio 
    ma_evaels =10000,                                     # maimum  umbtem of  valactions for optmrizatio,
    ng_.seed= 42,                                         # random seed for optmrizatio (controast bootstrap resampmes onlL)
    warp-preirsion = e-7                                  #dreimial preirsion to rtrainwthenseflecting eually ig  umbtem aspsesudo.in anily forun bound warping
 k)

# Sectingsbug estions:mer- Rrecommen eturtingssestins ion data oer whichyou, havetstoing prtos.:mer- Ift bootstrash not fitting due toftallingofef buandaym( vey higtf buandaymepeuatyd and ewn iperation),:mere o.icrlease ma_epeuaty_at_ distancw_factot from 00 e to0.1, or1.0, sto the gradienl desnent lghorthms hasmere o more.infrimatio abhout the buandaymednge.mer- Adhjusling theLROcutofef is anotherway, of cntroalwing how the model fndsd rate transitios..Higther valuesmere o lean ewher detected transitios..)

# Sectinns for MCMC wal)
# ...tall
sestins  shownphere are_defauls
 MCM.
sestins  <- list(
    MCM.bturtit = 0(
    MCM. steps = e30(
    MCM. ste._size = . 0(
    MCM. prtoe = . 0 (
    MCM.neigtborm.fieter =2g
 k)

# Fit model
# ...tall
sestins  shownphere are_defauls

laminar.model <- wisp(
    # Data to model
    count.data = countdata,
    # Variable labels
    variables = data.variablea,
    # Sectinns used o. Rsidc
     us.mmediit =FALSE0(
    MCM. Sectinns=  MCM. Sectinn",
    bootstras. umt = 0(
   con veged. resampme. only= TRUE0(
    ma. fokx = bs_chunksiz0(
   dim. buants = olMmeas(layhe. buanday. bise),
    vebtosy= TRUE0(
   {prin. chil. sumdaitey= TRUE0(
   
# Secting to asts to C++ model
    mode.
sestins =  mode.
sestinsg
 k)

#>Demo plots showing inaomy, ofa- wist
demo.sigmoid.plot()t
demo.warp.plot()  